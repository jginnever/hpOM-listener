java -jar hpOMListener-v1.5.jar server config.yml 
